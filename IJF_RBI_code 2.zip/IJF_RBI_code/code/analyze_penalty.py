"""Metrics for the RBI penalty-case LLM experiment (labels from RBI press releases)."""
import json, re, sys, numpy as np
from sklearn.metrics import f1_score
from scipy.stats import chi2
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
sys.path.insert(0, BASE + '/code')
R = BASE + '/results/'; D = BASE + '/data/rbi_pr/'
src = open(BASE + '/code/penalty_kb.py').read()
ns = {}; exec(src[:src.index('CATEGORY = {')], ns)  # RULES and canon()
canon = ns['canon']
rows = json.load(open(R + 'penalty_llm_results.json'))
n = len(rows) // 3 * 3
rows = rows[:n]  # complete rounds of the three areas only
rng = np.random.default_rng(42); B = 10000
C_FN, C_FP, C_H = 5.0, 1.0, 0.5
AREAS = ['AML/KYC', 'Credit', 'Other']


def norm_area(a):
    a = str(a or '').lower()
    return 'AML/KYC' if ('aml' in a or 'kyc' in a) else ('Credit' if 'credit' in a else 'Other')


def ci(v):
    v = np.asarray(v, float)
    if len(v) == 0:
        return [None] * 3
    bs = v[rng.integers(0, len(v), size=(B, len(v)))].mean(1)
    return [float(v.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def system(name):
    dir_ok, area_pred, esc, cites = [], [], [], []
    for r in rows:
        x = r[name] if name != 'A4' else r['FULL']
        if name == 'B1':
            d = canon(x.get('direction_text') or '')
            dir_ok.append(d in r['gold']); area_pred.append(norm_area(x.get('area'))); esc.append(False)
        else:
            dir_ok.append(x.get('direction') in r['gold']); area_pred.append(norm_area(x.get('area')))
            esc.append(bool(x.get('escalated')) if name == 'FULL' else False)
            cites += [bool(v) for _, v in x.get('ver', [])]
    y = np.array([r['category'] for r in rows]); a = np.array(area_pred); e = np.array(esc); ok = np.array(dir_ok)
    auto = ~e
    missed = int(((y == 'AML/KYC') & (a != 'AML/KYC') & auto).sum())
    other_wrong = int((auto & ~ok).sum()) - int(((y == 'AML/KYC') & (a != 'AML/KYC') & auto & ~ok).sum())
    return {'direction_accuracy_auto': ci(ok[auto]), 'direction_accuracy_all': ci(ok),
            'area_macro_f1_auto': float(f1_score(y[auto], a[auto], labels=AREAS, average='macro')) if auto.any() else None,
            'missed_aml_rate': missed / max(int((y == 'AML/KYC').sum()), 1), 'escalation_rate': float(e.mean()),
            'hallucinated_citation_rate': ci([not c for c in cites]) if cites else [None] * 3,
            'cost_per_case': (C_FN * missed + C_FP * other_wrong + C_H * int(e.sum())) / len(rows),
            '_ok': ok.tolist(), '_esc': e.tolist()}


out = {'n': len(rows), 'by_area': {k: sum(1 for r in rows if r['category'] == k) for k in AREAS}}
for s in ('B1', 'B4', 'A3', 'A4', 'FULL'):
    out[s] = system(s)
# McNemar (Equation 24) on direction correctness, all cases
tests = []
for a, b in (('B1', 'A4'), ('B4', 'A4'), ('A3', 'A4')):
    x = np.array(out[a]['_ok']); z = np.array(out[b]['_ok'])
    b01 = int((~x & z).sum()); b10 = int((x & ~z).sum()); nn = b01 + b10
    p = float(chi2.sf((abs(b01 - b10) - 1) ** 2 / nn, 1)) if nn else 1.0
    tests.append({'test': f'{a}_vs_{b}', 'b01': b01, 'b10': b10, 'p': p})
ps = [t['p'] for t in tests]; order = np.argsort(ps); prev = 0
for r_, i in enumerate(order):
    prev = max(prev, min(1.0, (len(ps) - r_) * ps[i])); tests[i]['p_holm'] = prev
out['tests'] = tests
# calibration of the retrieval-agreement confidence for FULL's automated direction
conf = np.array([r['FULL']['agreement'] for r in rows]); okf = np.array(out['A4']['_ok'], float)
bins = np.linspace(0, 1, 6); e_ = 0.0
for i in range(5):
    m = (conf >= bins[i]) & ((conf < bins[i + 1]) if i < 4 else (conf <= 1))
    if m.any():
        e_ += m.mean() * abs(okf[m].mean() - conf[m].mean())
out['ece_agreement'] = float(e_)
for s in ('B1', 'B4', 'A3', 'A4', 'FULL'):
    out[s].pop('_ok'); out[s].pop('_esc')
json.dump(out, open(R + 'penalty_llm_metrics.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
