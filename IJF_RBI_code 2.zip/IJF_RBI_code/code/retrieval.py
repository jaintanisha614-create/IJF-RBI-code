"""Retrieval experiment on all 406 IndiaFinBench items (no LLM involved).
Corpus = the 397 unique context passages of the benchmark (dev + test)."""
import json, re, numpy as np, pandas as pd, time
from rank_bm25 import BM25Okapi
from fastembed import TextEmbedding
from fastembed.rerank.cross_encoder import TextCrossEncoder

import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
D = BASE + '/data/'; R = BASE + '/results/'
df = pd.concat([pd.read_parquet(D + 'ifb_dev.parquet').assign(split='dev'),
                pd.read_parquet(D + 'ifb_test.parquet').assign(split='test')], ignore_index=True)
corpus = sorted(df.context.unique())
cid = {c: i for i, c in enumerate(corpus)}
df['gold'] = df.context.map(cid)
tok = lambda s: re.findall(r'[a-z0-9]+', s.lower())

t0 = time.time()
bm25 = BM25Okapi([tok(c) for c in corpus])
emb = TextEmbedding('BAAI/bge-small-en-v1.5')
C = np.array(list(emb.embed(corpus)))
Q = np.array(list(emb.query_embed(df.question.tolist())))
C /= np.linalg.norm(C, axis=1, keepdims=True); Q /= np.linalg.norm(Q, axis=1, keepdims=True)
ce = TextCrossEncoder('Xenova/ms-marco-MiniLM-L-6-v2')
print('models loaded', time.time() - t0)

KC, KF, TOPK = 20, 60, 5
runs = {'bm25': [], 'dense': [], 'hybrid': [], 'hybrid_rerank': []}
lat = {k: [] for k in runs}
for i, q in enumerate(df.question):
    t = time.time(); sb = bm25.get_scores(tok(q)); rb = list(np.argsort(-sb)); lat['bm25'].append(time.time() - t)
    t = time.time(); sd = C @ Q[i]; rd = list(np.argsort(-sd)); lat['dense'].append(time.time() - t)
    t = time.time()
    rrf = np.zeros(len(corpus))
    for r in (rb, rd):
        for rank, j in enumerate(r):
            rrf[j] += 1.0 / (KF + rank + 1)
    rh = list(np.argsort(-rrf)); lat['hybrid'].append(time.time() - t + lat['bm25'][-1] + lat['dense'][-1])
    t = time.time()
    cand = rh[:KC]
    sc = list(ce.rerank(q, [corpus[j] for j in cand]))
    rr = [cand[j] for j in np.argsort(-np.array(sc))] + rh[KC:]
    lat['hybrid_rerank'].append(time.time() - t + lat['hybrid'][-1])
    for k, r in (('bm25', rb), ('dense', rd), ('hybrid', rh), ('hybrid_rerank', rr)):
        runs[k].append([int(x) for x in r[:KC]])

rng = np.random.default_rng(42)
B = 10000
idx = rng.integers(0, len(df), size=(B, len(df)))
out = {}
per_item = {}
for k, r in runs.items():
    gold = df.gold.values
    rank = np.array([(ri.index(g) + 1) if g in ri else 10**6 for ri, g in zip(r, gold)])
    r1 = (rank <= 1).astype(float); r5 = (rank <= 5).astype(float); rr = np.where(rank <= KC, 1.0 / rank, 0.0)
    per_item[k] = {'r1': r1, 'r5': r5, 'rr': rr}
    def ci(v):
        bs = v[idx].mean(1); return [float(v.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
    out[k] = {'recall@1': ci(r1), 'recall@5': ci(r5), 'mrr@20': ci(rr), 'latency_ms': float(np.mean(lat[k]) * 1000)}
    out[k]['by_task_recall@5'] = {t: float(r5[(df.task_type == t).values].mean()) for t in df.task_type.unique()}
# paired bootstrap: hybrid_rerank vs others on recall@5
for k in ('bm25', 'dense', 'hybrid'):
    d = per_item['hybrid_rerank']['r5'] - per_item[k]['r5']
    bs = d[idx].mean(1)
    out['diff_hybrid_rerank_minus_' + k] = [float(d.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
d = per_item['hybrid']['r5'] - np.maximum(per_item['bm25']['r5'], 0) * 0 - per_item['bm25']['r5']
out['n_items'] = len(df); out['n_corpus'] = len(corpus)
json.dump(out, open(R + 'retrieval_metrics.json', 'w'), indent=1)
json.dump({'corpus': corpus, 'runs': runs, 'gold': df.gold.tolist(), 'ids': df.id.tolist()}, open(R + 'retrieval_runs.json', 'w'))
print(json.dumps(out, indent=1))
