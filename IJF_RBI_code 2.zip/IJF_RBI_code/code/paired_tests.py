"""Paired comparisons reported in the paper (Table 9), recomputed from the stored per-item outputs:
discordant counts, continuity-corrected McNemar statistic (Equation 24), asymptotic and exact binomial p-values,
Holm adjustment within each data set, and a paired bootstrap 95% interval for the difference in accuracy.
Output: results/paired_tests.json"""
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
_os.environ.setdefault('IJF_BASE', BASE)
import json, numpy as np
from scipy.stats import chi2, binomtest

R = BASE + '/results/'
src = open(BASE + '/code/penalty_kb.py').read(); ns = {}; exec(src[:src.index('CATEGORY = {')], ns); canon = ns['canon']
rng = np.random.default_rng(42); B = 10000

# IndiaFinBench: the same balanced 48-item selection as analyze_llm.py (first 12 per task in run order)
qa_all = json.load(open(R + 'qa_llm_results.json')); cnt = {}
for r in qa_all: cnt[r['task']] = cnt.get(r['task'], 0) + 1
nmin = min(cnt.values()); seen = {}; qa = []
for r in qa_all:
    seen[r['task']] = seen.get(r['task'], 0) + 1
    if seen[r['task']] <= nmin: qa.append(r)
acc = lambda s: np.array([bool(r[s]['correct']) for r in qa])
faith = lambda s: np.array([bool(r[s]['claims']) and all(c[2] for c in r[s]['claims']) for r in qa])

# RBI penalty cases: the same 45 cases and correctness rule as analyze_penalty.py
rows = json.load(open(R + 'penalty_llm_results.json')); rows = rows[:len(rows) // 3 * 3]


def ok(s):
    if s == 'B1':
        return np.array([canon(r['B1'].get('direction_text') or '') in r['gold'] for r in rows])
    k = 'FULL' if s == 'A4' else s  # A4 = full framework's decision without escalation
    return np.array([r[k].get('direction') in r['gold'] for r in rows])


def test(x, z):
    b01 = int((~x & z).sum()); b10 = int((x & ~z).sum()); n = b01 + b10
    stat = max(abs(b01 - b10) - 1, 0) ** 2 / n if n else 0.0
    p = float(chi2.sf(stat, 1)) if n else 1.0
    pe = float(binomtest(min(b01, b10), n, 0.5).pvalue) if n else 1.0
    d = z.astype(float) - x.astype(float); idx = rng.integers(0, len(d), size=(B, len(d))); bs = d[idx].mean(1)
    return dict(b01=b01, b10=b10, chi2=stat, p=p, p_exact=pe, diff=float(d.mean()),
                lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)))


def holm(ts, key, out):
    ps = [t[key] for t in ts]; order = np.argsort(ps); prev = 0
    for r_, i in enumerate(order):
        prev = max(prev, min(1.0, (len(ps) - r_) * ps[i])); ts[i][out] = prev


fam = {'qa': [('B1', 'B2', 'accuracy', acc), ('B1', 'B3', 'accuracy', acc), ('B1', 'B4', 'accuracy', acc),
              ('B4', 'FULL0', 'accuracy', acc), ('FULL0', 'FULL', 'faithful answers', faith)],
       'penalty': [('B1', 'B4', 'direction accuracy', None), ('B1', 'A4', 'direction accuracy', None),
                   ('B4', 'A4', 'direction accuracy', None), ('A3', 'A4', 'direction accuracy', None)]}
res = {}
for k, items in fam.items():
    ts = []
    for a, b, what, f in items:
        x, z = (f(a), f(b)) if f else (ok(a), ok(b))
        ts.append(dict(a=a, b=b, measure=what, n=len(x), **test(x, z)))
    holm(ts, 'p', 'p_holm'); holm(ts, 'p_exact', 'p_exact_holm'); res[k] = ts
json.dump(res, open(R + 'paired_tests.json', 'w'), indent=1)
for k, ts in res.items():
    for t in ts:
        print(k, f"{t['a']}->{t['b']} {t['measure']}: b01={t['b01']} b10={t['b10']} chi2={t['chi2']:.2f} "
                 f"p_holm={t['p_holm']:.4f} exact_holm={t['p_exact_holm']:.4f} diff={t['diff']:.3f} [{t['lo']:.3f}, {t['hi']:.3f}]")
