"""LLM experiment on a stratified random sample of the IndiaFinBench test split.
Generator: openai/gpt-oss-120b (temperature 0). Verifier: qwen/qwen3.8-27b. Judge: openai/gpt-oss-20b."""
import json, re, sys, random
import pandas as pd
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
sys.path.insert(0, BASE + '/code')
from llm import chat, parse_json, BudgetExhausted

R = BASE + '/results/'; D = BASE + '/data/'
GEN, VER, JUDGE = 'openai/gpt-oss-120b', 'qwen/qwen3.8-27b', 'openai/gpt-oss-20b'
N_PER_TASK = int(sys.argv[1]) if len(sys.argv) > 1 else 12
RR = json.load(open(R + 'retrieval_runs.json'))
corpus = RR['corpus']; pos = {i: k for k, i in enumerate(RR['ids'])}
test = pd.read_parquet(D + 'ifb_test.parquet')
groups = [g.sample(n=N_PER_TASK, random_state=42).reset_index(drop=True) for _, g in test.groupby('task_type')]
# round-robin across tasks so that a budget stop leaves the tasks balanced
sample = pd.DataFrame([g.iloc[i] for i in range(N_PER_TASK) for g in groups]).reset_index(drop=True)

SYS_RAG = ("You answer questions on Indian financial regulation using ONLY the numbered passages provided. "
           "Reply with a JSON object: {\"answer\": <short final answer>, \"claims\": [{\"claim\": <one factual statement supporting the answer>, \"passage\": <passage label such as \"P2\">}]}. "
           "Give one to three claims; every claim must cite exactly one passage label from the list. "
           "If the passages do not contain the answer, reply {\"answer\": \"insufficient evidence\", \"claims\": []}.")
SYS_CB = ("You answer questions on Indian financial regulation from your own knowledge. "
          "Reply with a JSON object: {\"answer\": <short final answer>}.")


def gen_rag(q, pids, feedback=None):
    ctx = '\n\n'.join(f'P{k + 1}: {corpus[p]}' for k, p in enumerate(pids))
    user = f'Passages:\n{ctx}\n\nQuestion: {q}'
    if feedback:
        user += ('\n\nYour previous claims below were NOT supported by the passage they cited. '
                 'Answer again, citing only passages that state each claim:\n' + feedback)
    out = chat(GEN, [{'role': 'system', 'content': SYS_RAG}, {'role': 'user', 'content': user}], max_tokens=700, tag='qa_gen')
    j = parse_json(out) or {'answer': out.strip()[:300], 'claims': []}
    j.setdefault('claims', [])
    return j


def verify(j, pids):
    """Return list of (claim, label, supported) ; citations outside Z are unsupported (hallucinated)."""
    res = []
    todo = []
    for c in j.get('claims', []) or []:
        if not isinstance(c, dict):
            continue
        lab = str(c.get('passage', '')).strip().upper()
        m = re.fullmatch(r'P(\d+)', lab)
        if not m or not (1 <= int(m.group(1)) <= len(pids)):
            res.append((c.get('claim', ''), lab, False, 'outside_Z'))
        else:
            todo.append((c.get('claim', ''), lab, corpus[pids[int(m.group(1)) - 1]]))
    if todo:
        items = '\n\n'.join(f'Item {k + 1}\nPassage: {p}\nClaim: {cl}' for k, (cl, lab, p) in enumerate(todo))
        out = chat(VER, [{'role': 'system', 'content': 'You check whether each claim is entailed by its passage. '
                          'A claim is entailed only if the passage states it or it follows directly from the passage. '
                          'Reply with JSON {"entailed": [true/false for each item in order]}.'},
                         {'role': 'user', 'content': items}], max_tokens=150, tag='qa_verify')
        j2 = parse_json(out) or {}
        ent = j2.get('entailed', [])
        for k, (cl, lab, p) in enumerate(todo):
            ok = bool(ent[k]) if k < len(ent) and isinstance(ent[k], bool) else False
            res.append((cl, lab, ok, 'checked'))
    return res


def norm(s):
    return re.sub(r'[^a-z0-9.%₹]+', ' ', str(s).lower()).strip()


def judge(q, ref, ans):
    if norm(ans) and (norm(ref) == norm(ans) or (len(norm(ref)) > 2 and norm(ref) in norm(ans))):
        return True
    if str(ans).strip().lower() == 'insufficient evidence':
        return False
    out = chat(JUDGE, [{'role': 'system', 'content': 'You grade answers to regulatory questions against a reference answer. '
                        'The candidate is correct if it states the same fact or value as the reference (numbers and units must match; extra explanation is fine). '
                        'Reply with JSON {"correct": true or false}.'},
                       {'role': 'user', 'content': f'Question: {q}\nReference answer: {ref}\nCandidate answer: {ans}'}],
               max_tokens=200, tag='qa_judge')
    j = parse_json(out) or {}
    return bool(j.get('correct', False))


results = []
for _, row in sample.iterrows():
    k = pos[row.id]; gold = RR['gold'][k]
    top = {s: RR['runs'][s][k][:5] for s in ('bm25', 'dense', 'hybrid', 'hybrid_rerank')}
    rec = {'id': row.id, 'task': row.task_type, 'gold': gold}
    try:
        cb = parse_json(chat(GEN, [{'role': 'system', 'content': SYS_CB}, {'role': 'user', 'content': row.question}],
                             max_tokens=500, tag='qa_gen')) or {}
        rec['B1'] = {'answer': cb.get('answer', ''), 'correct': judge(row.question, row.reference_answer, cb.get('answer', ''))}
        for name, ret in (('B2', 'bm25'), ('B3', 'dense'), ('B4', 'hybrid'), ('FULL0', 'hybrid_rerank')):
            j = gen_rag(row.question, top[ret])
            v = verify(j, top[ret])
            rec[name] = {'answer': j.get('answer', ''), 'claims': v, 'pids': top[ret],
                         'cites_gold': any(re.fullmatch(r'P(\d+)', l or '') and 1 <= int(l[1:]) <= 5 and top[ret][int(l[1:]) - 1] == gold for _, l, _, _ in v),
                         'correct': judge(row.question, row.reference_answer, j.get('answer', ''))}
        # verification + one regeneration (R = 1) for FULL (reranked) and A2 (no reranker = hybrid)
        for name, first, ret in (('FULL', 'FULL0', 'hybrid_rerank'), ('A2', 'B4', 'hybrid')):
            f = rec[first]
            G = (sum(1 for c in f['claims'] if c[2]) / len(f['claims'])) if f['claims'] else 0.0
            entry = {'G1': G, 'attempts': 1, 'answer': f['answer'], 'claims': f['claims'], 'correct': f['correct'], 'cites_gold': f['cites_gold']}
            if G < 1:
                fb = '\n'.join(f'- {c[0]} (cited {c[1]})' for c in f['claims'] if not c[2]) or '- no claims were given'
                j = gen_rag(row.question, top[ret], feedback=fb)
                v = verify(j, top[ret])
                G2 = (sum(1 for c in v if c[2]) / len(v)) if v else 0.0
                entry.update({'attempts': 2, 'answer': j.get('answer', ''), 'claims': v,
                              'cites_gold': any(re.fullmatch(r'P(\d+)', l or '') and 1 <= int(l[1:]) <= 5 and top[ret][int(l[1:]) - 1] == gold for _, l, _, _ in v),
                              'correct': judge(row.question, row.reference_answer, j.get('answer', '')), 'G2': G2})
                entry['escalated'] = G2 < 1
            else:
                entry['escalated'] = False
            rec[name] = entry
    except BudgetExhausted as e:
        print('BUDGET EXHAUSTED at', row.id, e); break
    results.append(rec)
    json.dump(results, open(R + 'qa_llm_results.json', 'w'), indent=1)
    print(len(results), row.id, {s: rec[s]['correct'] for s in ('B1', 'B2', 'B3', 'B4', 'FULL0', 'FULL', 'A2')}, 'esc', rec['FULL']['escalated'], flush=True)
print('done', len(results))
