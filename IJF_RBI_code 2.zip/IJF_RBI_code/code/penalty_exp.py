"""Experiments on real RBI penalty cases (Indian banks).
Stage 1 (all eligible cases, no LLM): retrieval of the governing direction (document-level Recall@k, MRR).
Stage 2 (stratified sample, LLM): direction and category decisions with citations, verification, escalation.
Gold labels are the directions named by RBI in each press release."""
import json, re, sys, collections
import numpy as np
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
sys.path.insert(0, BASE + '/code')
from rank_bm25 import BM25Okapi
from fastembed import TextEmbedding
from fastembed.rerank.cross_encoder import TextCrossEncoder
from llm import chat, parse_json, BudgetExhausted

D = BASE + '/data/rbi_pr/'; R = BASE + '/results/'
GEN, VER = 'openai/gpt-oss-120b', 'qwen/qwen3.8-27b'
N_PER_CAT = int(sys.argv[1]) if len(sys.argv) > 1 else 15
kb = json.load(open(D + 'penalty_kb.json')); ev = json.load(open(D + 'penalty_eval.json'))
keys = sorted({k for _, _, k in kb})
tok = lambda s: re.findall(r'[a-z0-9]+', s.lower())

# ---------------- stage 1: retrieval on all eligible cases ----------------
bm = BM25Okapi([tok(t) for _, t, _ in kb])
emb = TextEmbedding('BAAI/bge-small-en-v1.5')
E = np.array(list(emb.embed([t for _, t, _ in kb]))); E /= np.linalg.norm(E, axis=1, keepdims=True)
Q = np.array(list(emb.query_embed([c['charges'] for c in ev]))); Q /= np.linalg.norm(Q, axis=1, keepdims=True)
ce = TextCrossEncoder('Xenova/ms-marco-MiniLM-L-6-v2')
runs = {k: [] for k in ('bm25', 'dense', 'hybrid', 'hybrid_rerank')}
for i, c in enumerate(ev):
    rb = list(np.argsort(-bm.get_scores(tok(c['charges'])))); rd = list(np.argsort(-(E @ Q[i])))
    rrf = np.zeros(len(kb))
    for r in (rb, rd):
        for k, j in enumerate(r):
            rrf[j] += 1 / (61 + k)
    rh = list(np.argsort(-rrf)); cand = rh[:20]
    sc = list(ce.rerank(c['charges'], [kb[j][1] for j in cand]))
    rr = [cand[j] for j in np.argsort(-np.array(sc))] + rh[20:]
    for k, r in (('bm25', rb), ('dense', rd), ('hybrid', rh), ('hybrid_rerank', rr)):
        runs[k].append([int(x) for x in r[:20]])

rng = np.random.default_rng(42); B = 10000
idx = rng.integers(0, len(ev), size=(B, len(ev)))
ret = {'n_cases': len(ev), 'n_passages': len(kb), 'n_directions': len(keys)}
per = {}
for k, r in runs.items():
    rank = []
    for c, ri in zip(ev, r):
        hit = [n + 1 for n, j in enumerate(ri) if kb[j][2] in c['gold']]
        rank.append(hit[0] if hit else 10 ** 6)
    rank = np.array(rank)
    v1 = (rank <= 1).astype(float); v5 = (rank <= 5).astype(float); rr = np.where(rank <= 20, 1 / rank, 0.0)
    per[k] = v5
    ci = lambda v: [float(v.mean()), float(np.percentile(v[idx].mean(1), 2.5)), float(np.percentile(v[idx].mean(1), 97.5))]
    ret[k] = {'recall@1': ci(v1), 'recall@5': ci(v5), 'mrr@20': ci(rr)}
for k in ('bm25', 'dense', 'hybrid'):
    d = per['hybrid_rerank'] - per[k]; bs = d[idx].mean(1)
    ret['diff_rerank_minus_' + k] = [float(d.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
ret['categories'] = dict(collections.Counter(c['category'] for c in ev))
json.dump(ret, open(R + 'penalty_retrieval.json', 'w'), indent=1)
print(json.dumps(ret, indent=1)[:1500], flush=True)

# ---------------- stage 2: LLM decisions on a stratified sample ----------------
bycat = collections.defaultdict(list)
for i, c in enumerate(ev):
    bycat[c['category']].append(i)
groups = [list(rng.permutation(v)[:N_PER_CAT]) for _, v in sorted(bycat.items())]
order = [g[j] for j in range(N_PER_CAT) for g in groups if j < len(g)]  # round-robin across categories

SYS = ('You are a compliance officer at an Indian bank. A supervisory finding is given. Using ONLY the numbered RBI passages, '
       'identify the governing RBI direction and the compliance area. Reply with JSON {"governing_passage": <label such as "P2">, '
       '"area": "AML/KYC" or "Credit" or "Other", "claims": [{"claim": <statement linking the finding to the rule>, "passage": <label>}]}. '
       'Give one or two claims; each must cite one passage label.')
SYS_CB = ('You are a compliance officer at an Indian bank. A supervisory finding is given. From your own knowledge, name the RBI direction '
          'it breaches and the compliance area. Reply with JSON {"direction": <name>, "area": "AML/KYC" or "Credit" or "Other"}.')


def rag(c, pids, feedback=None):
    ctx = '\n\n'.join(f'P{k + 1} ({kb[j][0]}): {kb[j][1]}' for k, j in enumerate(pids))
    u = f'RBI passages:\n{ctx}\n\nSupervisory finding: {c["charges"]}'
    if feedback:
        u += '\n\nThese earlier claims were NOT supported by the passages they cited; answer again citing only supporting passages:\n' + feedback
    j = parse_json(chat(GEN, [{'role': 'system', 'content': SYS}, {'role': 'user', 'content': u}], max_tokens=800, tag='pen_gen')) or {}
    gp = str(j.get('governing_passage', '')).upper(); m = re.fullmatch(r'P(\d+)', gp)
    direc = kb[pids[int(m.group(1)) - 1]][2] if m and 1 <= int(m.group(1)) <= len(pids) else None
    return {'direction': direc, 'area': j.get('area'), 'claims': j.get('claims', []) or []}


def verify(claims, pids):
    out, todo = [], []
    for cl in claims:
        if not isinstance(cl, dict):
            continue
        m = re.fullmatch(r'P(\d+)', str(cl.get('passage', '')).strip().upper())
        if not m or not 1 <= int(m.group(1)) <= len(pids):
            out.append((cl.get('claim', ''), False))
        else:
            todo.append((cl.get('claim', ''), kb[pids[int(m.group(1)) - 1]][1]))
    if todo:
        items = '\n\n'.join(f'Item {k + 1}\nPassage: {p}\nClaim: {cl}' for k, (cl, p) in enumerate(todo))
        j = parse_json(chat(VER, [{'role': 'system', 'content': 'Check whether each claim is supported by its passage, treating statements about the '
                                   'supervisory finding as given facts. Reply with JSON {"entailed": [true/false for each item in order]}.'},
                                  {'role': 'user', 'content': items}], max_tokens=150, tag='pen_verify')) or {}
        e = j.get('entailed', [])
        out += [(cl, bool(e[k]) if k < len(e) and isinstance(e[k], bool) else False) for k, (cl, _) in enumerate(todo)]
    return out


rows = []
for i in order:
    c = ev[i]
    try:
        cb = parse_json(chat(GEN, [{'role': 'system', 'content': SYS_CB}, {'role': 'user', 'content': 'Supervisory finding: ' + c['charges']}],
                             max_tokens=600, tag='pen_gen')) or {}
        b4 = rag(c, runs['hybrid'][i][:5]); b4['ver'] = verify(b4['claims'], runs['hybrid'][i][:5])
        f0 = rag(c, runs['hybrid_rerank'][i][:5]); f0['ver'] = verify(f0['claims'], runs['hybrid_rerank'][i][:5])
        full = dict(f0); full['attempts'] = 1
        if not f0['ver'] or not all(v for _, v in f0['ver']):
            fb = '\n'.join(f'- {cl}' for cl, v in f0['ver'] if not v) or '- no claims were given'
            f1 = rag(c, runs['hybrid_rerank'][i][:5], feedback=fb); f1['ver'] = verify(f1['claims'], runs['hybrid_rerank'][i][:5])
            full = dict(f1); full['attempts'] = 2
        top = [kb[j][2] for j in runs['hybrid_rerank'][i][:5]]
        maj = collections.Counter(top).most_common(1)[0][0]
        full['agreement'] = top.count(full['direction']) / 5 if full['direction'] else 0.0
        full['omega'] = int(full['direction'] != maj)
        full['G1'] = (sum(v for _, v in f0['ver']) / len(f0['ver'])) if f0['ver'] else 0.0
        verified = bool(full['ver']) and all(v for _, v in full['ver'])
        full['escalated'] = (not verified) or full['omega'] == 1
    except BudgetExhausted as e:
        print('BUDGET EXHAUSTED', e); break
    rows.append({'prid': c['prid'], 'category': c['category'], 'gold': c['gold'],
                 'B1': {'direction_text': cb.get('direction', ''), 'area': cb.get('area')},
                 'B4': b4, 'A3': f0, 'FULL': full})
    json.dump(rows, open(R + 'penalty_llm_results.json', 'w'), indent=1, ensure_ascii=False)
    print(len(rows), c['prid'], c['category'], 'B4', b4['direction'] in c['gold'], 'A3', f0['direction'] in c['gold'],
          'FULL', full['direction'] in c['gold'], 'esc', full['escalated'], flush=True)
print('done', len(rows))
