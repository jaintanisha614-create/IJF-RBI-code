"""Collect RBI press releases on monetary penalties (www.rbi.org.in) for a prid range.
Saves the raw HTML of every release whose text mentions a monetary penalty, plus an index."""
import sys, os, re, html, json, time, urllib.request
from concurrent.futures import ThreadPoolExecutor

import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
OUT = BASE + '/data/rbi_pr/'
lo, hi = int(sys.argv[1]), int(sys.argv[2])
os.makedirs(OUT + 'pen', exist_ok=True)
PROXY = os.environ.get('HTTPS_PROXY')


def fetch(prid):
    fn = OUT + f'pen/{prid}.html'
    if os.path.exists(fn) or os.path.exists(OUT + f'pen/{prid}.skip'):
        return prid, 'cached'
    url = f'https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid={prid}'
    for a in range(4):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            t = urllib.request.urlopen(req, timeout=60).read().decode('utf-8', errors='ignore')
            break
        except Exception as e:
            time.sleep(3 + 3 * a)
    else:
        return prid, 'error'
    txt = html.unescape(re.sub(r'<[^>]+>', ' ', t))
    if re.search(r'monetary penalty', txt, re.I):
        open(fn, 'w').write(t); return prid, 'penalty'
    open(OUT + f'pen/{prid}.skip', 'w').write('')
    return prid, 'other'


stats = {}
with ThreadPoolExecutor(6) as ex:
    for i, (prid, s) in enumerate(ex.map(fetch, range(lo, hi + 1))):
        stats[s] = stats.get(s, 0) + 1
        if i % 200 == 0:
            print(i, stats, flush=True)
print('done', stats)
