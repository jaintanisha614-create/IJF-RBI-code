"""Parse RBI monetary-penalty press releases into structured cases (labels = RBI's own text)."""
import re, html, json, glob, os

import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
D = BASE + '/data/rbi_pr/'
MONTHS = 'January|February|March|April|May|June|July|August|September|October|November|December'


def clean(s):
    s = html.unescape(re.sub(r'<[^>]+>', ' ', s))
    return re.sub(r'\s+', ' ', s).strip()


def category(titles):
    t = ' '.join(titles).lower()
    if re.search(r'know your customer|kyc|money.laundering|aml|pmla|counter.?terror', t):
        return 'AML/KYC'
    if re.search(r'credit|loan|advance|income recognition|asset classification|interest rate|exposure|lending|priority sector|'
                 r'guarantee|wilful defaulter|fair practices|recovery agent|npa|provisioning|large exposures|board-approved policy for credit', t):
        return 'Credit'
    return 'Other'


cases = []
for fn in sorted(glob.glob(D + 'pen/*.html')):
    prid = int(os.path.basename(fn).split('.')[0])
    raw = open(fn, encoding='utf-8', errors='ignore').read()
    i = raw.find('monetary penalty')
    seg = raw[raw.rfind('<table', 0, i):]
    end = seg.find('Press Release:')
    seg = seg[:end] if end > 0 else seg[:30000]
    txt = clean(seg)
    m = re.search(r'Date\s*:\s*(\w{3} \d{1,2}, \d{4})', txt)
    date = m.group(1) if m else None
    tm = re.search(r'RBI imposes monetary penalty on (.+?) The Reserve Bank of India', txt)
    if not tm:
        continue
    entity = tm.group(1).strip()
    if 'Banking Regulation Act' not in txt:
        continue  # keep banks only (penalties under the Banking Regulation Act, 1949)
    first = txt[:txt.find('This penalty has been imposed')] if 'This penalty has been imposed' in txt else txt[:1500]
    titles = [x.strip() for x in re.findall(r'[‘“]([^’”]{8,250})[’”]', first)]
    links = sorted(set((u, clean(a)) for u, a in re.findall(r'href="([^"]+)"[^>]*>(.*?)</a>', seg, re.S)
                       if re.search(r'BS_ViewMas|NotificationUser|BS_ViewMasCircular|BS_CircularIndexDisplay|Notification', u, re.I)))
    am = re.search(r'financial position as on (\w+ \d{1,2}, \d{4})', txt)
    cm = (re.search(r'warranting imposition of monetary penalty\s*:\s*(.+?)\s*This action is based', txt)
          or re.search(r'revealed,? inter[- ]alia,? that (.+?)\s*In furtherance', txt)
          or re.search(r'revealed,? inter[- ]alia,? (.+?)\s*In furtherance', txt))
    pen = re.search(r'monetary penalty of (₹[\d.,]+ ?(?:lakh|crore)?)', txt)
    cases.append({'prid': prid, 'date': date, 'entity': entity, 'directions': titles, 'links': links,
                  'as_of': am.group(1) if am else None, 'charges': cm.group(1).strip() if cm else None,
                  'penalty': pen.group(1) if pen else None, 'category': category(titles) if titles else 'Statutory',
                  'cooperative': bool(re.search(r'co-?operative', entity, re.I))})
json.dump(cases, open(D + 'penalty_cases.json', 'w'), indent=1, ensure_ascii=False)
from collections import Counter
print(len(cases), Counter(c['category'] for c in cases), 'with charges', sum(1 for c in cases if c['charges']),
      'with links', sum(1 for c in cases if c['links']))
print(Counter(t for c in cases for t in c['directions']).most_common(40))
