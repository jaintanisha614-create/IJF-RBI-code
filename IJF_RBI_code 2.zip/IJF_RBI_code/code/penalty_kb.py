"""Canonicalise the RBI directions named in penalty releases, fetch the linked direction texts from rbi.org.in,
and split them into numbered-clause passages. Output: penalty_kb.json and penalty_eval.json."""
import re, json, html, os, urllib.request, collections

import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
D = BASE + '/data/rbi_pr/'
cases = json.load(open(D + 'penalty_cases.json'))

RULES = [  # (regex on lower-cased direction title, canonical key)
    (r'know your customer|\bkyc\b', 'Know Your Customer (KYC) Direction'),
    (r'credit information compan', 'Membership of Credit Information Companies'),
    (r'loans? and advances to directors', 'Loans and advances to directors and relatives'),
    (r'exposure norms', 'Exposure norms and statutory restrictions (UCBs)'),
    (r'income recognition|asset classification', 'Income recognition, asset classification and provisioning'),
    (r'priority sector', 'Priority sector lending'),
    (r'maintenance of deposit accounts', 'Maintenance of deposit accounts'),
    (r'interest rate on deposits', 'Interest rate on deposits'),
    (r'interest rate on advances', 'Interest rate on advances'),
    (r'placement of deposits', 'Placement of deposits with other banks'),
    (r'supervisory action framework', 'Supervisory action framework'),
    (r'fraud', 'Frauds: classification, reporting and monitoring'),
    (r'cash reserve ratio', 'Cash reserve ratio'),
    (r'financial statements', 'Financial statements: presentation and disclosures'),
    (r'management of advances', 'Management of advances (UCBs)'),
    (r'customer service|customer protection|unauthori[sz]ed electronic', 'Customer service and protection'),
    (r'depositor education|deaf', 'Depositor Education and Awareness Fund'),
    (r'cyber|information technology|it governance', 'Cyber security and IT'),
    (r'fair practices', 'Fair practices code'),
    (r'large exposures', 'Large exposures framework'),
    (r'gold loan|gold jewel', 'Gold loans'),
    (r'housing', 'Housing finance'),
    (r'investment', 'Investments'),
    (r'board of directors|chief executive|director', 'Governance of directors'),
]


def canon(title):
    t = title.lower()
    for rx, key in RULES:
        if re.search(rx, t):
            return key
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', t)).strip()


CATEGORY = {
    'Know Your Customer (KYC) Direction': 'AML/KYC',
    'Membership of Credit Information Companies': 'Credit', 'Loans and advances to directors and relatives': 'Credit',
    'Exposure norms and statutory restrictions (UCBs)': 'Credit', 'Income recognition, asset classification and provisioning': 'Credit',
    'Priority sector lending': 'Credit', 'Interest rate on advances': 'Credit', 'Management of advances (UCBs)': 'Credit',
    'Fair practices code': 'Credit', 'Large exposures framework': 'Credit', 'Gold loans': 'Credit', 'Housing finance': 'Credit',
}

for c in cases:
    c['gold'] = sorted(set(canon(x) for x in c['directions']))
    cats = {CATEGORY.get(g, 'Other') for g in c['gold']}
    c['category'] = 'AML/KYC' if 'AML/KYC' in cats else ('Credit' if 'Credit' in cats else ('Other' if cats else 'Statutory'))

# direction key -> URL, using the anchor text of each link in the release (so multi-direction releases map correctly)
url_for = {}
for c in cases:
    for u, a in c['links']:
        key = canon(a)
        if key in CATEGORY or re.search(r'[A-Z]', key):
            url_for.setdefault(key, u)
MANUAL = {  # RBI source documents located on rbi.org.in for directions that releases name without a link
    'Loans and advances to directors and relatives': 'https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=3324',
    'Placement of deposits with other banks': 'https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10122',
    'Exposure norms and statutory restrictions (UCBs)': 'https://www.rbi.org.in/Scripts/BS_ViewMasCirculardetails.aspx?id=12828',
    'Income recognition, asset classification and provisioning': 'https://www.rbi.org.in/Scripts/BS_ViewMasCirculardetails.aspx?id=12821',
    'Membership of Credit Information Companies': 'https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9525',
    'Supervisory action framework': 'https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11779',
    'Management of advances (UCBs)': 'https://www.rbi.org.in/Scripts/BS_ViewMasCirculardetails.aspx?id=12827',
    'Frauds: classification, reporting and monitoring': 'https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12703',
    'Maintenance of deposit accounts': 'https://www.rbi.org.in/Scripts/BS_ViewMasCirculardetails.aspx?id=5122',
}
for k, u in MANUAL.items():
    url_for.setdefault(k, u)
url_for = {k: u for k, u in url_for.items() if not re.match(r'^[a-z0-9 ]+$', k)}  # only canonical directions
print('directions with a source document:', len(url_for), sorted(url_for))


def fetch(url):
    fn = D + 'kb_' + re.sub(r'[^A-Za-z0-9]', '_', url)[-80:] + '.html'
    if not os.path.exists(fn):
        req = urllib.request.Request(url.replace('http://', 'https://'), headers={'User-Agent': 'Mozilla/5.0'})
        open(fn, 'w').write(urllib.request.urlopen(req, timeout=120).read().decode('utf-8', errors='ignore'))
    t = open(fn, encoding='utf-8', errors='ignore').read()
    t = re.sub(r'(?is)<(script|style).*?</\1>', ' ', t)
    t = re.sub(r'(?s)<br\s*/?>|</p>|</tr>|</li>|</h\d>', '\n', t)
    t = html.unescape(re.sub(r'<[^>]+>', ' ', t))
    return [re.sub(r'[ \t\xa0]+', ' ', l).strip() for l in t.split('\n') if l.strip()]


kb = []
for key, url in sorted(url_for.items()):
    try:
        lines = fetch(url)
    except Exception as e:
        print('fetch failed', key, url, e); continue
    # keep the document body: from the circular reference line (RBI/...) onwards
    start = next((k for k, l in enumerate(lines) if re.match(r'^RBI/', l)), 0)
    body = lines[start:]
    endk = next((k for k, l in enumerate(body) if re.match(r'^(Top|Follow Us|Disclaimer|Site Map)\b', l, re.I) and k > len(body) * 0.8), len(body))
    body = body[:endk]
    psg = []; cur = None
    for l in body:
        mm = re.match(r'^(\(?[ivx\d]+(?:\.\d+){0,4}\)?\.?)\s+(.*)', l)
        if mm and len(l.split()) >= 4:
            if cur and len(cur[1].split()) >= 15:
                psg.append(cur)
            cur = (f'{key} para {mm.group(1).strip("().")}', l)
        elif cur:
            cur = (cur[0], cur[1] + ' ' + l)
    if cur and len(cur[1].split()) >= 15:
        psg.append(cur)
    if len(psg) < 8:  # short circulars without numbered clauses: 100-word windows over the body
        words = ' '.join(body).split()
        psg = [(f'{key} part {n + 1}', ' '.join(words[i:i + 100])) for n, i in enumerate(range(0, max(len(words) - 20, 1), 80))]
    kb += [(lab, ' '.join(txt.split()[:120]), key) for lab, txt in psg]
    print(key, len(psg), 'passages')
json.dump(kb, open(D + 'penalty_kb.json', 'w'), ensure_ascii=False)

ev = [c for c in cases if c['charges'] and c['gold'] and all(g in url_for for g in c['gold'])]
json.dump(ev, open(D + 'penalty_eval.json', 'w'), indent=1, ensure_ascii=False)
print('cases', len(cases), 'eligible', len(ev), collections.Counter(c['category'] for c in ev))
print(collections.Counter(g for c in ev for g in c['gold']).most_common())
