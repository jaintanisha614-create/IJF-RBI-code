"""Independent re-derivation of the numbers in Tables 6 to 9 from raw per-item outputs, with a fresh re-run of the
deterministic penalty retrieval stage (no language-model calls). Writes results/verification_report.json and
results/penalty_retrieval_runs.json (first relevant rank of every case for every retrieval configuration)."""
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
_os.environ.setdefault('IJF_BASE', BASE)
import json, numpy as np, collections

R = BASE + '/results/'; D = BASE + '/data/rbi_pr/'
rep = {}

# ---- Table 6 (IndiaFinBench): from stored ranked lists and gold passage ids ----
rr = json.load(open(R + 'retrieval_runs.json'))
t6 = {}
for k, runs in rr['runs'].items():
    rank = np.array([(r.index(g) + 1) if g in r else 10**6 for r, g in zip(runs, rr['gold'])])
    t6[k] = [round(float((rank <= 1).mean()), 3), round(float((rank <= 5).mean()), 3),
             round(float(np.where(rank <= 20, 1 / rank, 0).mean()), 3)]
rep['table6_indiafinbench'] = {'n': len(rr['gold']), **t6}

# ---- Table 6 (penalty): fresh re-run of the deterministic retrieval stage of penalty_exp.py ----
src = open(BASE + '/code/penalty_exp.py').read().replace('from llm import chat, parse_json, BudgetExhausted', '')
stage1 = src[:src.index('rng = np.random.default_rng(42); B = 10000')]
ns = {}; exec(stage1, ns)
kb, ev, runs = ns['kb'], ns['ev'], ns['runs']
t6p, ranks = {}, {}
for k, r in runs.items():
    rank = np.array([next((n + 1 for n, j in enumerate(ri) if kb[j][2] in c['gold']), 10**6) for c, ri in zip(ev, r)])
    ranks[k] = rank.tolist()
    t6p[k] = [round(float((rank <= 1).mean()), 3), round(float((rank <= 5).mean()), 3),
              round(float(np.where(rank <= 20, 1 / rank, 0).mean()), 3)]
rep['table6_penalty'] = {'n': len(ev), **t6p}
json.dump({'prid': [c['prid'] for c in ev], 'gold': [c['gold'] for c in ev], 'first_relevant_rank': ranks},
          open(R + 'penalty_retrieval_runs.json', 'w'))

# ---- Table 7: from per-question outputs (balanced 48: first 12 per task in run order) ----
qa_all = json.load(open(R + 'qa_llm_results.json')); seen = collections.Counter(); qa = []
nmin = min(collections.Counter(r['task'] for r in qa_all).values())
for r in qa_all:
    seen[r['task']] += 1
    if seen[r['task']] <= nmin: qa.append(r)
t7 = {}
for s in ('B1', 'B2', 'B3', 'B4', 'FULL0', 'A2', 'FULL'):
    esc = np.array([bool(r[s].get('escalated', False)) for r in qa]); cor = np.array([bool(r[s]['correct']) for r in qa])
    row = {'released': round(float((~esc).mean()), 3), 'acc_released': round(float(cor[~esc].mean()), 3)}
    if s != 'B1':
        cl = [c for r in qa for c in r[s]['claims']]
        row['faithful'] = round(float(np.mean([bool(r[s]['claims']) and all(c[2] for c in r[s]['claims']) for r in qa])), 3)
        row['halluc'] = round(float(np.mean([not c[2] for c in cl])), 3)
    t7[s] = row
rep['table7'] = {'n': len(qa), 'per_task': dict(collections.Counter(r['task'] for r in qa)), **t7}

# ---- Table 8: from per-case outputs; gold = directions named by RBI ----
ns2 = {}; s2 = open(BASE + '/code/penalty_kb.py').read(); exec(s2[:s2.index('CATEGORY = {')], ns2); canon = ns2['canon']
rows = json.load(open(R + 'penalty_llm_results.json')); rows = rows[:len(rows) // 3 * 3]
area = lambda a: 'AML/KYC' if any(x in str(a or '').lower() for x in ('aml', 'kyc')) else ('Credit' if 'credit' in str(a or '').lower() else 'Other')
t8 = {}
for s in ('B1', 'B4', 'A3', 'A4', 'FULL'):
    ok, esc, a_pred, cites = [], [], [], []
    for r in rows:
        x = r['FULL'] if s == 'A4' else r[s]
        d = canon(x.get('direction_text') or '') if s == 'B1' else x.get('direction')
        ok.append(d in r['gold']); a_pred.append(area(x.get('area'))); esc.append(s == 'FULL' and bool(x.get('escalated')))
        if s != 'B1': cites += [bool(v) for _, v in x.get('ver', [])]
    ok, esc, a_pred = np.array(ok), np.array(esc), np.array(a_pred); y = np.array([r['category'] for r in rows]); auto = ~esc
    miss = (y == 'AML/KYC') & (a_pred != 'AML/KYC') & auto
    other = int((auto & ~ok).sum()) - int((miss & ~ok).sum())
    t8[s] = {'decided': int(auto.sum()), 'dir_acc': round(float(ok[auto].mean()), 3),
             'missed_kyc': round(float(miss.sum() / (y == 'AML/KYC').sum()), 3),
             'failed_cit': round(float(np.mean([not c for c in cites])), 3) if cites else None, 'esc': round(float(esc.mean()), 3),
             'cost': round(float((5 * miss.sum() + other + 0.5 * esc.sum()) / len(rows)), 3)}
rep['table8'] = {'n': len(rows), 'per_area': dict(collections.Counter(r['category'] for r in rows)), **t8}
if _os.path.exists(R + 'paired_tests.json'):
    rep['table9'] = json.load(open(R + 'paired_tests.json'))
json.dump(rep, open(R + 'verification_report.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in rep.items() if k != 'table9'}, indent=1))
