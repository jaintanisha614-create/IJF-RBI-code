"""Aggregate LLM experiment results with bootstrap CIs and exact McNemar tests (Holm-corrected)."""
import json, numpy as np
from math import comb
from sklearn.metrics import f1_score

import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
R = BASE + '/results/'
rng = np.random.default_rng(42)
B = 10000


def ci(v):
    v = np.asarray(v, float)
    if len(v) == 0:
        return [None, None, None]
    idx = rng.integers(0, len(v), size=(B, len(v)))
    bs = v[idx].mean(1)
    return [float(v.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def mcnemar_exact(a, b):
    """a, b boolean correctness vectors. Two-sided exact binomial test on discordant pairs."""
    a = np.asarray(a, bool); b = np.asarray(b, bool)
    b01 = int((~a & b).sum()); b10 = int((a & ~b).sum()); n = b01 + b10
    if n == 0:
        return b01, b10, 1.0
    from scipy.stats import chi2
    stat = (abs(b01 - b10) - 1) ** 2 / n  # Equation (24), continuity-corrected
    return b01, b10, float(chi2.sf(stat, 1))


def holm(ps):
    order = np.argsort(ps); m = len(ps); adj = [0] * m; prev = 0
    for r, i in enumerate(order):
        val = min(1.0, (m - r) * ps[i]); prev = max(prev, val); adj[i] = prev
    return adj


out = {}
# ---------------- QA ----------------
qa_all = json.load(open(R + 'qa_llm_results.json'))
_cnt = {}
for r in qa_all: _cnt[r['task']] = _cnt.get(r['task'], 0) + 1
_nmin = min(_cnt.values()) if len(_cnt) == 4 else 0
_seen = {}; qa = []
for r in qa_all:
    _seen[r['task']] = _seen.get(r['task'], 0) + 1
    if _seen[r['task']] <= _nmin: qa.append(r)
out['qa_n'] = len(qa)
out['qa_tasks'] = {t: sum(1 for r in qa if r['task'] == t) for t in sorted({r['task'] for r in qa})}
sysqa = {}
for s in ('B1', 'B2', 'B3', 'B4', 'FULL0', 'A2', 'FULL'):
    corr = [bool(r[s]['correct']) for r in qa]
    d = {'accuracy': ci(corr)}
    if s != 'B1':
        cl = [c for r in qa for c in r[s]['claims']]
        sup = [bool(c[2]) for c in cl]
        d['n_citations'] = len(cl)
        d['hallucinated_citation_rate'] = ci([not x for x in sup]) if cl else [None] * 3
        d['citation_precision'] = ci(sup) if cl else [None] * 3
        d['faithful_answers'] = ci([bool(r[s]['claims']) and all(c[2] for c in r[s]['claims']) for r in qa])
        d['gold_passage_cited'] = ci([bool(r[s]['cites_gold']) for r in qa])
    if s in ('FULL', 'A2'):
        esc = [bool(r[s]['escalated']) for r in qa]
        d['escalation_rate'] = ci(esc)
        keep = [not e for e in esc]
        d['selective_accuracy'] = ci([c for c, k in zip(corr, keep) if k])
        d['regenerated_share'] = float(np.mean([r[s]['attempts'] == 2 for r in qa]))
    sysqa[s] = d
out['qa'] = sysqa
# paired tests on accuracy and on per-answer faithfulness
tests = []
for a, b, key in (('B1', 'FULL', 'correct'), ('B4', 'FULL', 'correct'), ('B2', 'FULL', 'correct'), ('FULL0', 'FULL', 'correct')):
    x = [bool(r[a][key]) for r in qa]; y = [bool(r[b][key]) for r in qa]
    tests.append([f'{a}_vs_{b}_accuracy', *mcnemar_exact(x, y)])
for a, b in (('B4', 'FULL'), ('FULL0', 'FULL')):
    f = lambda r, s: bool(r[s]['claims']) and all(c[2] for c in r[s]['claims'])
    tests.append([f'{a}_vs_{b}_faithful', *mcnemar_exact([f(r, a) for r in qa], [f(r, b) for r in qa])])
adj = holm([t[3] for t in tests])
out['qa_tests'] = [{'test': t[0], 'b01': t[1], 'b10': t[2], 'p': t[3], 'p_holm': p} for t, p in zip(tests, adj)]

# ---------------- credit LLM ----------------
try:
    cr = json.load(open(R + 'credit_llm_results.json'))
    rows = cr['rows'][: len(cr['rows']) // 2 * 2]  # complete default/non-default pairs only
    y = np.array([r['y'] for r in rows])
    C_FP, C_FN, C_H = 1.0, 5.0, 0.5
    def m(act, ver=None):
        act = np.array([2 if a is None else a for a in act])
        auto = act != 2
        fn = int(((act == 0) & (y == 1)).sum()); fp = int(((act == 1) & (y == 0)).sum()); esc = int((act == 2).sum())
        return {'macro_f1_auto': float(f1_score(y[auto], act[auto], average='macro')) if auto.any() else None,
                'missed_risk_rate': fn / max(int((y == 1).sum()), 1), 'escalation_rate': esc / len(y),
                'cost_per_case': (C_FN * fn + C_FP * fp + C_H * esc) / len(y), 'unparsed': int(sum(1 for a in act if a == 2)) if ver == 'raw' else None}
    full = [2 if (r['esc_rule'] or not r['B5_ver'] or not all(r['B5_ver'])) else r['B5'] for r in rows]
    cm = {'n': len(rows), 'defaults': int(y.sum()), 'kb_size': cr['kb_size'], 'Z': cr['Z'],
          'B1': m([r['B1'] for r in rows], 'raw'), 'A5_no_tools': m([r['A5'] for r in rows], 'raw'),
          'B5_agent': m([r['B5'] for r in rows], 'raw'), 'FULL': m(full)}
    for s, k in (('A5_no_tools', 'A5_ver'), ('B5_agent', 'B5_ver')):
        v = [x for r in rows for x in r[k]]
        cm[s]['hallucinated_citation_rate'] = ci([not x for x in v]) if v else None
        cm[s]['n_citations'] = len(v)
    acc = lambda key: [r[key] == r['y'] for r in rows]
    t2 = [['B1_vs_B5', *mcnemar_exact(acc('B1'), acc('B5'))], ['A5_vs_B5', *mcnemar_exact(acc('A5'), acc('B5'))]]
    adj = holm([t[3] for t in t2])
    cm['tests'] = [{'test': t[0], 'b01': t[1], 'b10': t[2], 'p': t[3], 'p_holm': p} for t, p in zip(t2, adj)]
    cm['agent_agrees_with_tool_rule'] = float(np.mean([r['B5'] == int(r['p'] >= 1 / 6 or r['rule'] == 1) for r in rows]))
    out['credit_llm'] = cm
except FileNotFoundError:
    pass

# ---------------- token usage ----------------
u = [json.loads(l) for l in open(R + 'llm_usage.jsonl')]
tok = {}
for r in u:
    t = tok.setdefault(r['model'], {'calls': 0, 'tokens': 0}); t['calls'] += 1; t['tokens'] += r['total'] or 0
out['usage'] = tok
json.dump(out, open(R + 'llm_metrics.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
