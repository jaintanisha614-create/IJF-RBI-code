"""Expected cost per case under alternative cost weights (Figure 7 and the break-even points in Section 5.3).
A wrong automated decision costs 1, a missed KYC breach costs w_kyc, and a referral to an officer costs w_h;
escalated cases are assumed to be resolved correctly by the officer. Counts come from the per-case outputs.
Output: results/cost_sensitivity.json (counts, break-even points, and the cost grid used for Figure 7)."""
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
_os.environ.setdefault('IJF_BASE', BASE)
import json, numpy as np

R = BASE + '/results/'
src = open(BASE + '/code/penalty_kb.py').read(); ns = {}; exec(src[:src.index('CATEGORY = {')], ns); canon = ns['canon']
rows = json.load(open(R + 'penalty_llm_results.json')); rows = rows[:len(rows) // 3 * 3]
N = len(rows)
area = lambda a: 'AML/KYC' if any(x in str(a or '').lower() for x in ('aml', 'kyc')) else ('Credit' if 'credit' in str(a or '').lower() else 'Other')

counts = {}
for s in ('B1', 'B4', 'A3', 'A4', 'FULL'):
    miss = other = esc = 0
    for r in rows:
        x = r['FULL'] if s == 'A4' else r[s]
        d = canon(x.get('direction_text') or '') if s == 'B1' else x.get('direction')
        escalated = s == 'FULL' and bool(x.get('escalated'))
        if escalated:
            esc += 1; continue
        m = r['category'] == 'AML/KYC' and area(x.get('area')) != 'AML/KYC'
        if m: miss += 1
        elif d not in r['gold']: other += 1
    counts[s] = {'missed_kyc': miss, 'other_wrong': other, 'escalated': esc}

cost = lambda s, wk, wh: (wk * counts[s]['missed_kyc'] + counts[s]['other_wrong'] + wh * counts[s]['escalated']) / N
assert abs(cost('FULL', 5, 0.5) - 0.467) < 0.001 and abs(cost('B4', 5, 0.5) - 0.378) < 0.001  # Table 6

c = counts
# Full framework cheaper than hybrid retrieval (B4) at w_kyc = 5 when w_h is below this value
be_full_b4 = (5 * c['B4']['missed_kyc'] + c['B4']['other_wrong'] - 5 * c['FULL']['missed_kyc'] - c['FULL']['other_wrong']) / c['FULL']['escalated']
# No retrieval (B1) cheapest only when it beats every other system
b1 = c['B1']['other_wrong'] + 0  # B1 missed no KYC breach
wk_min = max((b1 - c[s]['other_wrong']) / c[s]['missed_kyc'] for s in ('B4', 'A3', 'A4') if c[s]['missed_kyc'])
wh_min = (b1 - c['FULL']['other_wrong']) / c['FULL']['escalated']
wk_grid = [1, 2, 3, 5, 7.5, 10, 15, 20]; wh_grid = [round(x, 2) for x in np.linspace(0, 1, 21)]
grid = {s: [[round(cost(s, wk, wh), 4) for wh in wh_grid] for wk in wk_grid] for s in counts}
out = {'n': N, 'counts': counts, 'break_even': {'full_beats_B4_at_wkyc5_if_wh_below': be_full_b4,
       'B1_cheapest_if_wkyc_above': wk_min, 'B1_cheapest_if_wh_above': wh_min},
       'wkyc_grid': wk_grid, 'wh_grid': wh_grid, 'cost': grid}
json.dump(out, open(R + 'cost_sensitivity.json', 'w'), indent=1)
print(json.dumps({'counts': counts, 'break_even': out['break_even']}, indent=1))
