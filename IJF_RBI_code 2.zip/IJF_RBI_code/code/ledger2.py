"""Hash-chained ledger over every LLM decision produced in the experiments (IndiaFinBench answers and RBI penalty-case decisions),
followed by tamper injection: each record is altered once and the chain re-verified."""
import json, hashlib, time

import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
R = BASE + '/results/'
qa = json.load(open(R + 'qa_llm_results.json'))
pen = json.load(open(R + 'penalty_llm_results.json'))
MANDATORY = ['case_id', 'as_of', 'input_digest', 'evidence', 'claims', 'decision', 'escalated', 'model_version']
H = lambda b: hashlib.sha256(b).hexdigest()

recs = []
for r in qa:
    for s in ('B1', 'B2', 'B3', 'B4', 'FULL0', 'A2', 'FULL'):
        x = r[s]
        recs.append({'case_id': f"indiafinbench:{r['id']}:{s}", 'as_of': 'benchmark', 'input_digest': H(r['id'].encode()),
                     'evidence': x.get('pids', ['closed-book']) or ['closed-book'], 'claims': [c[0] for c in x.get('claims', [])] or ['none'],
                     'decision': str(x.get('answer', '')) or 'none', 'escalated': bool(x.get('escalated', False)), 'model_version': 'gpt-oss-120b'})
for r in pen:
    for s in ('B1', 'B4', 'A3', 'A4', 'FULL'):
        if s == 'B1':
            x = {'direction': r['B1'].get('direction_text'), 'area': r['B1'].get('area'), 'ver': []}
        elif s == 'A4':
            x = dict(r['FULL']); x['escalated'] = False  # A4: the full framework's decision without escalation
        else:
            x = r[s]
        recs.append({'case_id': f"rbi-penalty:{r['prid']}:{s}", 'as_of': 'inspection date in release', 'input_digest': H(str(r['prid']).encode()),
                     'evidence': [x.get('direction') or 'none'], 'claims': [c[0] for c in x.get('ver', [])] or ['none'],
                     'decision': f"{x.get('direction')}|{x.get('area')}", 'escalated': bool(x.get('escalated', False)), 'model_version': 'gpt-oss-120b'})

t0 = time.perf_counter(); h = H(b'genesis'); blobs, chain = [], []
for rec in recs:
    s = json.dumps(rec, sort_keys=True).encode(); h = H(h.encode() + s); blobs.append(s); chain.append(h)
append_ms = (time.perf_counter() - t0) / len(recs) * 1000
atc = sum(sum(1 for f in MANDATORY if json.loads(b).get(f) not in (None, '', [])) / len(MANDATORY) for b in blobs) / len(blobs)


def verify(bs):
    h = H(b'genesis')
    for i, s in enumerate(bs):
        h = H(h.encode() + s)
        if h != chain[i]:
            return i
    return None


t0 = time.perf_counter(); assert verify(blobs) is None; vms = (time.perf_counter() - t0) / len(blobs) * 1000 * 1000
det = loc = 0
for j in range(len(blobs)):
    rec = json.loads(blobs[j]); rec['decision'] = rec['decision'] + ' (altered)'
    k = verify(blobs[:j] + [json.dumps(rec, sort_keys=True).encode()] + blobs[j + 1:])
    det += k is not None; loc += k == j
out = {'records': len(blobs), 'atc': atc, 'trials': len(blobs), 'detected': det, 'located_exactly': loc,
       'verify_ms_per_1000': vms, 'append_ms_per_decision': append_ms}
json.dump(out, open(R + 'ledger2_metrics.json', 'w'), indent=1)
print(out)
