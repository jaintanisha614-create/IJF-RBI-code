"""Groq chat client with on-disk cache, per-model TPM pacing and 429 handling.
Every call and its usage is logged so token budgets can be reported exactly."""
import json, os, time, hashlib, urllib.request, urllib.error, threading

_kf = os.path.expanduser('~/.secrets/groq_key')
KEY = os.environ.get('GROQ_API_KEY') or (open(_kf).read().strip() if os.path.exists(_kf) else None)  # needed only on a cache miss
URL = 'https://api.groq.com/openai/v1/chat/completions'
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(globals().get('__file__', _os.path.join('code', 'x')))))
_os.environ.setdefault('IJF_BASE', BASE)
CACHE = BASE + '/results/llm_cache.jsonl'
LOG = BASE + '/results/llm_usage.jsonl'
_lock = threading.Lock()
_cache = {}
if os.path.exists(CACHE):
    for line in open(CACHE):
        try:
            r = json.loads(line); _cache[r['k']] = r
        except Exception:
            pass

_window = {}  # model -> list of (t, tokens)
TPM = 7600     # stay under the 8K TPM limit


class BudgetExhausted(Exception):
    pass


def _pace(model, est):
    while True:
        now = time.time()
        w = [(t, n) for t, n in _window.get(model, []) if now - t < 60]
        _window[model] = w
        if sum(n for _, n in w) + est <= TPM:
            return
        time.sleep(1.0)


def chat(model, messages, max_tokens=400, temperature=0.0, tag='', extra=None):
    body = {'model': model, 'messages': messages, 'max_tokens': max_tokens, 'temperature': temperature}
    if model.startswith('openai/gpt-oss'):
        body['reasoning_effort'] = 'low'
    if model.startswith('qwen/'):
        body['reasoning_effort'] = 'none'
    if extra:
        body.update(extra)
    k = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    if k in _cache:
        return _cache[k]['content']
    if not KEY:
        raise RuntimeError('This request is not in results/llm_cache.jsonl; set GROQ_API_KEY to call the Groq API.')
    est = sum(len(m['content']) for m in messages) // 4 + max_tokens // 3
    for attempt in range(8):
        _pace(model, est)
        req = urllib.request.Request(URL, data=json.dumps(body).encode(), headers={
            'Authorization': 'Bearer ' + KEY, 'Content-Type': 'application/json', 'User-Agent': 'curl/8.5.0'})
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                d = json.loads(resp.read())
            break
        except urllib.error.HTTPError as e:
            msg = e.read().decode(errors='ignore')
            if e.code == 429:
                if 'per day' in msg or 'TPD' in msg or 'RPD' in msg:
                    raise BudgetExhausted(msg[:300])
                ra = float(e.headers.get('retry-after', 5) or 5)
                time.sleep(min(ra + 1, 65)); continue
            if e.code >= 500:
                time.sleep(5); continue
            raise RuntimeError(f'{e.code} {msg[:300]}')
        except (urllib.error.URLError, TimeoutError):
            time.sleep(5); continue
    else:
        raise RuntimeError('retries exhausted')
    content = d['choices'][0]['message'].get('content') or ''
    u = d.get('usage', {})
    with _lock:
        _window.setdefault(model, []).append((time.time(), u.get('total_tokens', est)))
        rec = {'k': k, 'model': model, 'content': content}
        _cache[k] = rec
        with open(CACHE, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        with open(LOG, 'a') as f:
            f.write(json.dumps({'t': time.time(), 'model': model, 'tag': tag,
                                'prompt': u.get('prompt_tokens'), 'completion': u.get('completion_tokens'),
                                'total': u.get('total_tokens')}) + '\n')
    return content


def parse_json(text):
    """Extract the first JSON object from a model reply."""
    s = text.find('{'); e = text.rfind('}')
    if s < 0 or e < s:
        return None
    try:
        return json.loads(text[s:e + 1])
    except Exception:
        return None
