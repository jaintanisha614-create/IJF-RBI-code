"""Paired bootstrap intervals for differences in Recall@5 between retrieval configurations (Section 5.1).
IndiaFinBench uses results/retrieval_runs.json; penalty cases use results/penalty_retrieval_runs.json,
which verify_results.py writes. Output: results/retrieval_differences.json"""
import os as _os
BASE = _os.environ.get('IJF_BASE') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
_os.environ.setdefault('IJF_BASE', BASE)
import json, numpy as np

R = BASE + '/results/'; B = 10000


def boot(d, seed=42):
    rng = np.random.default_rng(seed); idx = rng.integers(0, len(d), size=(B, len(d))); bs = d[idx].mean(1)
    return {'diff': float(d.mean()), 'lo': float(np.percentile(bs, 2.5)), 'hi': float(np.percentile(bs, 97.5)), 'n': int(len(d))}


rr = json.load(open(R + 'retrieval_runs.json'))
hit = {k: np.array([g in r[:5] for r, g in zip(runs, rr['gold'])], float) for k, runs in rr['runs'].items()}
pr = json.load(open(R + 'penalty_retrieval_runs.json'))
hitp = {k: (np.array(v) <= 5).astype(float) for k, v in pr['first_relevant_rank'].items()}
out = {'indiafinbench': {'hybrid_rerank_minus_bm25': boot(hit['hybrid_rerank'] - hit['bm25']),
                         'hybrid_minus_bm25': boot(hit['hybrid'] - hit['bm25'])},
       'penalty': {'bm25_minus_hybrid_rerank': boot(hitp['bm25'] - hitp['hybrid_rerank']),
                   'bm25_minus_hybrid': boot(hitp['bm25'] - hitp['hybrid'])}}
json.dump(out, open(R + 'retrieval_differences.json', 'w'), indent=1)
for ds, d in out.items():
    for k, v in d.items():
        print(ds, k, f"{v['diff']:.3f} [{v['lo']:.3f}, {v['hi']:.3f}]")
