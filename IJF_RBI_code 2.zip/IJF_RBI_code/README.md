# Code for "Retrieval-Grounded LLM Framework for Regulatory Compliance in Indian Banks"

This folder holds the Python code, the parsed data, and the raw outputs behind every number in the paper.

## Quick start (Google Colab)

Upload `IJF_RBI_code.zip`, open `run_in_colab.ipynb` (or run `!unzip -q IJF_RBI_code.zip`, `%cd /content/IJF_RBI_code`,
`!pip install -q rank_bm25 fastembed pyarrow`), then run the scripts as `!python code/<script>.py`. No API key is needed:
all language-model calls used in the paper are replayed from `results/llm_cache.jsonl`.

## Folder layout

```
code/      Python scripts (run from this folder's root, e.g. `python code/paired_tests.py`)
data/      parsed RBI penalty cases, knowledge base, and the 206-case test set
results/   raw model outputs, cache, usage log, and computed metrics
```

Paths are resolved relative to this folder. To keep the folder elsewhere, set `IJF_BASE=/path/to/IJF_RBI_code`.

## Scripts, in run order

| Step | Script | What it does | Paper |
|---|---|---|---|
| 1 | `scrape_rbi_penalties.py` | Downloads RBI press releases 56000 to 61700 and keeps the monetary-penalty releases | Sec. 4.5 |
| 2 | `parse_penalties.py` | Extracts bank, cited directions, inspection date, charges, penalty amount | Sec. 4.5 |
| 3 | `penalty_kb.py` | Maps cited titles to directions (24 rules), fetches direction texts, splits them into clause passages, applies the exclusions (628 → 206) | Sec. 4.5, App. B |
| 4 | `retrieval.py` | BM25, dense, hybrid (RRF) and reranked retrieval on IndiaFinBench | Table 4 |
| 5 | `llm.py` | Groq API client with on-disk cache, token pacing and usage log (imported by 6 and 7) | Sec. 4.6 |
| 6 | `llm_qa.py` | Generation, claim verification, regeneration and judging on 48 IndiaFinBench questions (12 per task type) | Table 5, App. A |
| 7 | `penalty_exp.py` | Retrieval on all 206 penalty cases; generation, verification and escalation on 45 cases (15 per area) | Tables 4 and 6, App. A |
| 8 | `analyze_llm.py` | Metrics and bootstrap intervals for the questions | Table 5 |
| 9 | `analyze_penalty.py` | Metrics, cost, missed-KYC rate and ECE (5 equal-width bins) for the penalty cases | Table 6, Sec. 5.4 |
| 10 | `paired_tests.py` | McNemar (Eq. 24), exact binomial, Holm adjustment, paired bootstrap intervals | Figure 6b |
| 11 | `ledger2.py` | Hash-chained ledger of all 561 outputs and the tamper-evidence test | Sec. 5.4 |
| 12 | `verify_results.py` | Recomputes all retrieval, answer and penalty-case results from raw outputs and re-runs penalty retrieval | Tables 4 to 6 (check) |
| 13 | `retrieval_differences.py` | Paired bootstrap intervals for Recall@5 differences (needs step 12 output) | Sec. 5.1 |
| 14 | `cost_sensitivity.py` | Cost per case under alternative cost weights and the break-even points | Figure 7, Sec. 5.3 |

Steps 8 to 11, 13 and 14 need no internet and no API key; they run in seconds from the files in `results/`.
Steps 1 to 4 and 12 download data or models (rbi.org.in, Hugging Face). `retrieval.py` and `llm_qa.py` expect the IndiaFinBench
parquet files as `data/ifb_dev.parquet` and `data/ifb_test.parquet`, downloaded from the IndiaFinBench release on Hugging Face (Pall, 2026).
Steps 6 and 7 call the Groq API. Every call made for the paper is stored in `results/llm_cache.jsonl`,
so re-running them replays the cached answers instead of calling the API again.

## Models

The encoder is `BAAI/bge-small-en-v1.5` and the reranker is `Xenova/ms-marco-MiniLM-L-6-v2`, the ONNX export of
`cross-encoder/ms-marco-MiniLM-L-6-v2` that fastembed loads. Random sampling and bootstrap use seed 42 with 10,000 resamples.

## API key

Steps 6 and 7 read the Groq key from the environment variable `GROQ_API_KEY`
(or from `~/.secrets/groq_key`). No key is included in this folder.

## Software

Python 3.13. Libraries: rank_bm25, fastembed, numpy, pandas, scipy, scikit-learn (see `requirements.txt`).
The exact library versions used in October 2026 were not recorded, so `requirements.txt` does not pin them.

## Notes

- Timings in `results/ledger2_metrics.json` (milliseconds per append and per 1,000 verifications) vary from run to run.
- Diagrams (Figures 1 to 9) are not part of the experiments and are not included here.
